package netty;

/**
 * @author wonseok.song
 * @since 2021-02-05
 */
public class Test {

  public static void main(String[] args) {
    System.out.println("1");
  }
}
