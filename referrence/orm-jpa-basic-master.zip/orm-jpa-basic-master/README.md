# orm-jpa-basic

- [자바 ORM 표준 JPA 프로그래밍 강의](https://www.inflearn.com/course/ORM-JPA-Basic#curriculum)를 통한 JPA 학습

## 스터디

- [스터디 일정](https://github.com/team-zunior/orm-jpa-basic)

## 개인

- 강의 관련 프로젝트 진행
- [내용 정리](https://github.com/namjunemy/TIL#jpa)
- 블로그 작성

