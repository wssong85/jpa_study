package hello.jpa;

public enum RoleType {
    USER,
    ADMIN
}
