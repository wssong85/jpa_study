package jpql.domain;

public enum MemberType {
    ADMIN, USER
}
