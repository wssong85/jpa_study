package io.namjune.shop.domain;

public enum DeliveryStatus {
}
