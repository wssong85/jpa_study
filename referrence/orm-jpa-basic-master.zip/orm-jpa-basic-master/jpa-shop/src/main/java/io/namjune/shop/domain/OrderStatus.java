package io.namjune.shop.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
